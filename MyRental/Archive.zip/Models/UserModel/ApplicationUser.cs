﻿using System;
using Microsoft.AspNetCore.Identity;

namespace MyRental.Models.UserModel
{
    public class ApplicationUser : IdentityUser
    {
        
    }
}
