﻿using System;
namespace MyRental.Models
{
    public class CustomSettings
    {
        public static string ConnectionString { get; set; }
    }
}
